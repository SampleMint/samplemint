import { useRouter } from 'next/router';
import { useEffect, useRef, useState } from 'react';
import { useSession } from '@supabase/auth-helpers-react';
import { supabase } from '../../utils/supabaseClient';

export default function PaperViewer() {
  const router = useRouter();
  const session = useSession();
  const [showMenu, setShowMenu] = useState(false);
  const [pdfUrl, setPdfUrl] = useState(null);
  const [loading, setLoading] = useState(true);
  const [purchase, setPurchase] = useState(false);
  const [loadError, setLoadError] = useState(false);

  const handleLogout = async () => {
    await supabase.auth.signOut();
    router.replace('/');
  };

  const handleRetry = () => {
    setLoadError(false);
    router.reload();
  };

  useEffect(() => {
    if (!router.isReady || !session) return;

    const id = router.query.id;
    if (!id || typeof id !== 'string') {
      setLoadError(true);
      return;
    }

    const init = async () => {
      const cacheKey = `paper_${id}_purchased`;
      const cached = sessionStorage.getItem(cacheKey);

      if (cached === 'true') {
        const publicUrl = supabase.storage
          .from('paper')
          .getPublicUrl(`${id}.pdf`).data.publicUrl;

        setPdfUrl(publicUrl);
        setPurchase(true);
        setLoading(false);
        return;
      }

      try {
        const { data: purchaseData, error: purchaseError } = await supabase
          .from('purchases')
          .select('*')
          .eq('user_id', session.user.id)
          .eq('product_id', id)
          .single();

        if (purchaseError || !purchaseData) {
          setPurchase(false);
          setLoading(false);
          return;
        }

        const publicUrl = supabase.storage
          .from('public-papers')
          .getPublicUrl(`${id}.pdf`).data.publicUrl;

        sessionStorage.setItem(cacheKey, 'true');
        setPdfUrl(publicUrl);
        setPurchase(true);
        setLoading(false);
      } catch (err) {
        console.error('Unexpected error:', err);
        setLoadError(true);
        setLoading(false);
      }
    };

    init();
  }, [router.isReady, session]);

  if (loading) {
    return (
      <div style={{ textAlign: 'center', padding: '3rem' }}>
        <div className="spinner"></div>
        <p>Loading...</p>
        <style jsx>{`
          .spinner {
            border: 4px solid rgba(0, 0, 0, 0.1);
            width: 36px;
            height: 36px;
            border-radius: 50%;
            border-left-color: #09f;
            animation: spin 1s linear infinite;
            margin: 0 auto 10px;
          }
          @keyframes spin {
            to {
              transform: rotate(360deg);
            }
          }
        `}</style>
      </div>
    );
  }

  if (loadError) {
    return (
      <div style={{ textAlign: 'center', padding: '3rem' }}>
        <p>Something went wrong. Please try again.</p>
        <button onClick={handleRetry} style={{ marginTop: '1rem', padding: '0.5rem 1rem' }}>
          Retry
        </button>
      </div>
    );
  }

  if (!session) {
    return (
      <div style={{ textAlign: 'center', padding: '3rem' }}>
        <p>Please login to view this page.</p>
        <button onClick={() => router.push('/login')} style={{ marginTop: '1rem' }}>
          Go to Login
        </button>
      </div>
    );
  }

  if (!purchase) {
    return (
      <div className="p-10 text-center">
        You have not purchased this sample paper yet.
        <br />
        <a href="/dashboard" className="text-blue-600 underline">
          Go to Dashboard
        </a>
      </div>
    );
  }

  const LazyPreviewIframe = ({ pdfUrl }) => {
    const [showIframe, setShowIframe] = useState(false);
    const containerRef = useRef(null);

    useEffect(() => {
      const observer = new IntersectionObserver(
        ([entry]) => {
          if (entry.isIntersecting) {
            setShowIframe(true);
            observer.disconnect();
          }
        },
        { rootMargin: '200px' }
      );

      if (containerRef.current) {
        observer.observe(containerRef.current);
      }

      return () => observer.disconnect();
    }, []);

    return (
      <div ref={containerRef}>
        {showIframe ? (
          <iframe
            src={`https://docs.google.com/gview?url=${encodeURIComponent(pdfUrl)}&embedded=true`}
            width="100%"
            height="600px"
            style={{ border: '1px solid #ccc' }}
            sandbox="allow-scripts allow-same-origin"
          />
        ) : (
          <div style={{ height: '600px', backgroundColor: '#f0f0f0', textAlign: 'center', paddingTop: '2rem', color: '#777' }}>
            Loading preview...
            <br />
            📄 Scroll to load the sample paper
          </div>
        )}
      </div>
    );
  };

  return (
    <div>
      {/* NAVBAR */}
      <nav className="navbar">
        <div className="navbar-left">
          <div className="navbar-brand">
            <span className="brand-text">SampleMint</span>
          </div>
          <button className="menu-btn" onClick={() => setShowMenu(!showMenu)}>☰</button>
        </div>

        <div className={`navbar-user ${showMenu ? 'show' : ''}`}>
          {session?.user && <div className="user-email">Hi, {session.user.email}</div>}
          <button onClick={() => router.push('/dashboard')} className="nav-link">Dashboard</button>
          <button onClick={handleLogout} className="logout-btn">Logout</button>
        </div>
      </nav>

      <main className="container">
        <h1 className="text-xl font-bold mb-4">Your Purchased Sample Paper</h1>
        <p>Logged in as: <strong>{session?.user?.email || 'Unknown'}</strong></p>
        <p style={{ fontSize: 14, color: '#cc0000', marginTop: 12, textAlign: 'center' }}>
          *If the PDF is showing "No Preview", please scroll down or refresh the page.*
        </p>

        <div style={{ position: 'relative', marginTop: 20 }}>
          {pdfUrl && <LazyPreviewIframe pdfUrl={pdfUrl} />}
          <div style={{
            position: 'absolute',
            top: 10,
            right: 10,
            background: 'rgba(255,255,255,0.8)',
            padding: '4px 8px',
            fontSize: 12,
            borderRadius: 4,
          }}>
            🔒 View Only — No Download
          </div>
        </div>

        <p style={{ fontSize: 12, marginTop: 10, color: '#555' }}>
          Watermarked for: {session?.user?.email || 'Unknown'}
        </p>
      </main>

      {/* FOOTER */}
      <footer className="footer">
        &copy; {new Date().getFullYear()} SampleMint. All rights reserved.
      </footer>

      {/* STYLES */}
      <style jsx>{`
        .navbar {
          display: flex;
          background: #007bff;
          color: white;
          padding: 16px;
          flex-direction: column;
        }
        .navbar-left {
          display: flex;
          justify-content: space-between;
          align-items: center;
        }
        .navbar-brand {
          font-size: 24px;
          font-weight: bold;
          display: flex;
          align-items: center;
        }
        .brand-text {
          margin-left: 10px;
          font-size: 28px;
          font-weight: 800;
        }
        .menu-btn {
          font-size: 24px;
          background: none;
          border: none;
          color: white;
          display: block;
          cursor: pointer;
        }
        .navbar-user {
          display: none;
          flex-direction: column;
          align-items: flex-start;
          padding-top: 10px;
        }
        .navbar-user.show {
          display: flex;
        }
        .nav-link {
          background-color: #10b981;
          color: white;
          padding: 8px 16px;
          border-radius: 6px;
          border: none;
          cursor: pointer;
          font-weight: 600;
          margin-top: 8px;
        }
        .logout-btn {
          background-color: #ef4444;
          border: none;
          padding: 8px 16px;
          border-radius: 6px;
          color: white;
          cursor: pointer;
          font-weight: 600;
        }
        .container {
          padding: 40px 30px;
          min-height: 100vh;
        }
        .footer {
          text-align: center;
          padding: 20px;
          background: #007bff;
          margin-top: 40px;
          font-size: 14px;
          color: white;
        }
        @media (min-width: 768px) {
          .navbar {
            flex-direction: row;
            justify-content: space-between;
            align-items: center;
          }
          .menu-btn {
            display: none;
          }
          .navbar-user {
            display: flex !important;
            flex-direction: row;
            align-items: center;
            gap: 16px;
            padding-top: 0;
          }
          .user-email {
            font-size: 16px;
            margin-bottom: 0;
          }
        }
      `}</style>
    </div>
  );
}
