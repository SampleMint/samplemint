// pages/_app.js
import { useEffect } from 'react';
import '../styles/globals.css';
import { SessionContextProvider } from '@supabase/auth-helpers-react';
import { supabase } from '../utils/supabaseClient';
// _app.js or inside your layout
export default function MyApp({ Component, pageProps }) {
  useEffect(() => {
    // Disable right-click
    const handleContextMenu = (e) => e.preventDefault();
    document.addEventListener('contextmenu', handleContextMenu);

    // Block keyboard shortcuts
    const blockKeys = (e) => {
      if (
        e.key === 'PrintScreen' ||
        (e.ctrlKey && ['s', 'p', 'u', 'c'].includes(e.key.toLowerCase())) ||
        (e.metaKey && e.key.toLowerCase() === 'c')
      ) {
        e.preventDefault();
      }
    };
    window.addEventListener('keydown', blockKeys);

    // Clear clipboard on PrintScreen
    const clearClipboard = () => {
      navigator.clipboard.writeText('');
      alert('Screenshot is disabled!');
    };
    const detectPrintScreen = (e) => {
      if (e.key === 'PrintScreen') {
        clearClipboard();
      }
    };
    window.addEventListener('keyup', detectPrintScreen);

    // Cleanup on unmount
    return () => {
      document.removeEventListener('contextmenu', handleContextMenu);
      window.removeEventListener('keydown', blockKeys);
      window.removeEventListener('keyup', detectPrintScreen);
    };
  }, []);
  return (
    <SessionContextProvider supabaseClient={supabase} initialSession={pageProps.initialSession}>
      <Component {...pageProps} />
    </SessionContextProvider>
  );
}
