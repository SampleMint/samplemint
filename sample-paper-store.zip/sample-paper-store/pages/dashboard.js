import { useEffect, useState, useCallback } from 'react';
import { useRouter } from 'next/router';
import { supabase } from '../utils/supabaseClient';
import Script from 'next/script';

const subjects = [
  { name: 'Accounting For Managers', id: 'accounting-for-managers', preview: 'https://hrltupylgpzcktwoiobz.supabase.co/storage/v1/object/public/previews/accounting-for-managers.png'},
  { name: 'Professional Communication', id: 'professional-communication', preview: 'https://hrltupylgpzcktwoiobz.supabase.co/storage/v1/object/public/previews/professional-communication.png'},
  { name: 'Managerial Economics', id: 'managerial-economics', preview: 'https://hrltupylgpzcktwoiobz.supabase.co/storage/v1/object/public/previews/managerial-economics.png'},
  { name: 'Marketing Management', id: 'marketing-management', preview: 'https://hrltupylgpzcktwoiobz.supabase.co/storage/v1/object/public/previews/marketing-management.png' },
  { name: 'Statistics For Management', id: 'statistics-for-management', preview: 'https://hrltupylgpzcktwoiobz.supabase.co/storage/v1/object/public/previews/statistics-for-management.png'},
];

export default function Dashboard() {
  const [loadingSpinner, setLoadingSpinner] = useState(false);
  const [loadingMessage, setLoadingMessage] = useState('');
  const router = useRouter();
  const [user, setUser] = useState(null);
  const [modalImage, setModalImage] = useState(null);
  const [showMenu, setShowMenu] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (!data.session) {
        router.replace('/');
      } else {
        setUser(data.session.user);
      }
    });
  }, [router]);

  const handleLogout = async () => {
    await supabase.auth.signOut();
    router.replace('/');
  };

  const handleBuy = async (subjectId, subjectName) => {
    if (!user) return alert("Please log in first");

    const cacheKey = `paper_${subjectId}_purchased`;
    const alreadyPurchased = sessionStorage.getItem(cacheKey);
    if (alreadyPurchased === 'true') {
        setLoadingSpinner(true);
        setLoadingMessage('Redirecting to paper...');
        setTimeout(() => router.push(`/paper/${subjectId}`), 5000);
        return;
    }

    if (process.env.NODE_ENV === 'development') {
      const { error } = await supabase.from('purchases').insert([
        { user_id: user.id, product_id: subjectId },
      ]);
      if (!error) {
        sessionStorage.setItem(cacheKey, 'true');
        setLoadingSpinner(true);
        setLoadingMessage('Redirecting to paper...');
        setTimeout(() => router.push(`/paper/${subjectId}`), 5000);
      } else {
        alert('Purchase failed: ' + error.message);
      }
      return;
    }

    const options = {
      key: process.env.NEXT_PUBLIC_RAZORPAY_KEY,
      amount: 9900,
      currency: 'INR',
      name: 'SampleMint',
      description: `Purchase access to ${subjectName}`,
      handler: async function (response) {
        const { error } = await supabase.from('purchases').insert([
          { user_id: user.id, product_id: subjectId },
        ]);
        if (!error) {
          sessionStorage.setItem(cacheKey, 'true');
          setLoadingSpinner(true);
          setLoadingMessage('Redirecting to paper...');
          setTimeout(() => router.push(`/paper/${subjectId}`), 5000);
        } else {
          alert('Purchase failed: ' + error.message);
        }
      },
      prefill: {
        email: user.email,
      },
      theme: { color: '#2563EB' },
    };

    const rzp = new window.Razorpay(options);
    rzp.open();
  };
 const handleMyCourses = useCallback(() => {
  setLoadingSpinner(true);
  setLoadingMessage('Redirecting to My Purchases...');
  setTimeout(() => router.push('/my-courses'), 5000);
}, [router]);
  return (
    <div>
      <Script src="https://checkout.razorpay.com/v1/checkout.js" />
      <nav className="navbar">
        <div className="navbar-left">
          <div className="navbar-brand"><span className="brand-text">SampleMint</span></div>
          <button className="menu-btn" onClick={() => setShowMenu(!showMenu)}>☰</button>
        </div>
        <div className={`navbar-user ${showMenu ? 'show' : ''}`}>
          {user && <div className="user-email">Hi, {user.email}</div>}
          <button onClick={handleMyCourses} className="nav-link">My Purchases</button>
          <button onClick={handleLogout} className="logout-btn">Logout</button>
        </div>
      </nav>

      <main className="container">
        <h1 className="heading">Available Sample Papers</h1>
         <h2 className="heading">Each Set Consist of 5 Quality Sample Papers</h2>
        <div className="paper-list">
          {subjects.map((subject) => (
            <div className="paper-card" key={subject.id}>
              <img
                src={subject.preview}
                alt="Preview"
                className="preview-img"
                onClick={() => setModalImage(subject.preview)}
                style={{ cursor: 'pointer' }}
              />
              <div className="paper-info">
                <h2>{subject.name}</h2>
                <p>(Pack of 5)</p>
                <p>Price: ₹99</p>
                <button onClick={() => handleBuy(subject.id, subject.name)}>Buy Now</button>
              </div>
            </div>
          ))}
        </div>
      </main>

      {modalImage && (
        <div className="modal-overlay" onClick={() => setModalImage(null)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <img src={modalImage} alt="Full Preview" className="modal-img" />
            <button className="close-btn" onClick={() => setModalImage(null)}>✕</button>
          </div>
        </div>
      )}

      <footer className="footer">
        &copy; {new Date().getFullYear()} SampleMint. All rights reserved.
      </footer>

      <style jsx>{`
      * {
          box-sizing: border-box;
        }
        body {
          margin: 0;
          font-family: Arial, sans-serif;
        }

        .navbar {
          display: flex;
          background: #007bff;
          color: white;
          padding: 16px;
          flex-direction: column;
        }
        .navbar-left {
           display: flex;
           justify-content: space-between;
           align-items: center;
         }

.navbar-brand {
  font-size: 24px;
  font-weight: bold;
  display: flex;
  align-items: center;
}

.brand-text {
  margin-left: 10px;
  font-size: 28px;
  font-weight: 800;
}
.menu-btn {
  font-size: 24px;
  background: none;
  border: none;
  color: white;
  display: block;
  cursor: pointer;
}

.navbar-user {
  display: none;
  flex-direction: column;
  align-items: flex-start;
  padding-top: 10px;
}

.navbar-user.show {
  display: flex;
}
  .logout-btn {
  background-color: #ef4444;
  border: none;
  padding: 8px 16px;
  border-radius: 6px;
  color: white;
  cursor: pointer;
  font-weight: 600;
}

        .logo {
          font-size: 2rem;
          font-weight: bold;
          letter-spacing: 1px;
        }

        .user span {
          margin-right: 20px;
        }

        .user button {
          background: #ff4d4f;
          border: none;
          color: white;
          padding: 8px 12px;
          border-radius: 4px;
          cursor: pointer;
        }

        .container {
          padding: 40px 30px;
          min-height: 100vh;
        }

        .heading {
          text-align: center;
          font-size: 32px;
          margin-bottom: 40px;
        }

        .paper-list {
          display: flex;
          flex-wrap: wrap;
          gap: 20px;
          justify-content: center;
        }

        .paper-card {
          display: flex;
          flex-direction: column;
          width: 280px;
          border: 1px solid #ccc;
          border-radius: 10px;
          overflow: hidden;
          background: #fff;
        }

        .preview-img {
          width: 100%;
          height: 180px;
          object-fit: contain;
        }

        .paper-info {
          padding: 15px;
        }

        .paper-info h2 {
          font-size: 18px;
          margin-bottom: 10px;
        }

        .paper-info p {
          margin-bottom: 10px;
          color: #333;
        }

        .paper-info button {
          background: #28a745;
          color: white;
          padding: 8px 12px;
          border: none;
          border-radius: 4px;
          cursor: pointer;
        }

        .footer {
          text-align: center;
          padding: 20px;
          background: #007bff;
          margin-top: 40px;
          font-size: 14px;
        }
        html, body {
          height: auto;
          min-height: 100vh;
          overflow-x: hidden;
          overflow-y: auto;
          margin: 0;
          padding: 0;
        }
          .nav-link {
          background-color: #10b981;
          color: white;
          padding: 8px 16px;
          border-radius: 6px;
          border: none;
          cursor: pointer;
          font-weight: 600;
          margin-top: 8px;
        }
          .loading-overlay {
  position: fixed;
  top: 0;
  left: 0;
  z-index: 9999;
  width: 100vw;
  height: 100vh;
  background: rgba(255, 255, 255, 0.9);
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}

.spinner {
  border: 8px solid #e0e0e0;
  border-top: 8px solid #2563EB;
  border-radius: 50%;
  width: 60px;
  height: 60px;
  animation: spin 1s linear infinite;
  margin-bottom: 20px;
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

@media (min-width: 768px) {
  .nav-link {
    margin-top: 0;
  }
}

@media (min-width: 768px) {
  .navbar {
    flex-direction: row;
    justify-content: space-between;
    align-items: center;
  }

  .menu-btn {
    display: none;
  }

  .navbar-user {
    display: flex !important;
    flex-direction: row;
    align-items: center;
    gap: 16px;
    padding-top: 0;
  }

  .user-email {
    font-size: 16px;
    margin-bottom: 0;
      }
      }
        @media (max-width: 600px) {
          .paper-list {
            flex-direction: column;
            align-items: center;
          }

          .logo {
            font-size: 1.5rem;
          }
        }
        /* existing CSS is same as you already have + modal CSS added */
        .modal-overlay {
          position: fixed;
          top: 0;
          left: 0;
          width: 100vw;
          height: 100vh;
          background-color: rgba(0, 0, 0, 0.8);
          display: flex;
          justify-content: center;
          align-items: center;
          z-index: 9999;
        }
        .modal-content {
          position: relative;
          max-width: 90%;
          max-height: 90%;
          background: white;
          padding: 10px;
          border-radius: 10px;
          overflow: hidden;
        }
        .modal-img {
          max-width: 100%;
          max-height: 80vh;
          object-fit: contain;
          border-radius: 8px;
        }
        .close-btn {
          position: absolute;
          top: 8px;
          right: 12px;
          background: #ef4444;
          color: white;
          border: none;
          border-radius: 50%;
          font-size: 18px;
          width: 30px;
          height: 30px;
          cursor: pointer;
        }
      `}</style>
      {loadingSpinner && (
  <div className="loading-overlay">
    <div className="spinner"></div>
    <p>{loadingMessage || 'Please wait...'}</p>
  </div>
)}
    </div>
  );
}
