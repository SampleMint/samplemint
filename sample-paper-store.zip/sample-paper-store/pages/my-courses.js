import { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import { supabase } from '../utils/supabaseClient';

const subjects = {
  'accounting-for-managers': {
    name: 'Accounting For Managers',
    preview: 'https://hrltupylgpzcktwoiobz.supabase.co/storage/v1/object/public/previews/accounting-for-managers.png',
  },
  'professional-communication': {
    name: 'Professional Communication',
    preview: 'https://hrltupylgpzcktwoiobz.supabase.co/storage/v1/object/public/previews/professional-communication.png',
  },
  'managerial-economics': {
    name: 'Managerial Economics',
    preview: 'https://hrltupylgpzcktwoiobz.supabase.co/storage/v1/object/public/previews/managerial-economics.png',
  },
  'marketing-management': {
    name: 'Marketing Management',
    preview: 'https://hrltupylgpzcktwoiobz.supabase.co/storage/v1/object/public/previews/marketing-management.png',
  },
  'statistics-for-management': {
    name: 'Statistics For Management',
    preview: 'https://hrltupylgpzcktwoiobz.supabase.co/storage/v1/object/public/previews/statistics-for-management.png',
  },
};

export default function MyCourses() {
  const router = useRouter();
  const [user, setUser] = useState(null);
  const [purchases, setPurchases] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showMenu, setShowMenu] = useState(false);
  const [loadingPaper, setLoadingPaper] = useState(null); // holds the productId that is currently loading

  const fetchPurchases = async () => {
    setLoading(true);
    const {
      data: { session },
    } = await supabase.auth.getSession();

    if (!session) {
      router.replace('/login');
      return;
    }

    setUser(session.user);

    const { data, error } = await supabase
      .from('purchases')
      .select(`
        product_id,
        product:product_id (
          name,
          preview_path,
          pdf_path
        )
      `)
      .eq('user_id', session.user.id);

    if (error) {
      console.error('Error fetching purchases:', error);
    } else {
      setPurchases(data);
    }

    setLoading(false);
  };

  useEffect(() => {
    if (!router.isReady) return;

    fetchPurchases();
  }, [router.isReady]);

  const handleLogout = async () => {
    await supabase.auth.signOut();
    router.replace('/');
  };

 const handleView = (productId) => {
       setLoadingPaper(productId); // set loading state for spinner
       setTimeout(() => {
       router.push(`/paper/${productId}`);
      }, 10000); // 10 seconds delay
     };
  // Prevent render until router is ready
  if (!router.isReady) return null;

  return (
    <div>
      {/* Navbar */}
      <nav className="navbar">
        <div className="navbar-left">
          <div className="navbar-brand">
            <span className="brand-text">SampleMint</span>
          </div>
          <button className="menu-btn" onClick={() => setShowMenu(!showMenu)}>☰</button>
        </div>

        <div className={`navbar-user ${showMenu ? 'show' : ''}`}>
          {user && (
            <>
              <div className="user-email">Hi, {user.email}</div>
              <button onClick={() => router.push('/dashboard')} className="nav-link">Dashboard</button>
              <button onClick={handleLogout} className="logout-btn">Logout</button>
            </>
          )}
        </div>
      </nav>

      {/* Main Content */}
      <main className="container">
        <h1 className="heading">My Purchased Papers</h1>
        {loading ? (
          <p style={{ textAlign: 'center' }}>Loading...</p>
        ) : !user ? (
          <p style={{ textAlign: 'center' }}>Please login to view your purchases.</p>
        ) : purchases.length === 0 ? (
          <p style={{ textAlign: 'center' }}>You haven't purchased any papers yet.</p>
        ) : (
          <div className="grid">
            {purchases.map((purchase) => {
              const product = purchase.product;
              if (!product) return null;

              const subject = subjects[purchase.product_id] || {
                name: product.name || 'Unknown Subject',
                preview: product.preview_path || '/fallback.png',
              };

              return (
                <div key={purchase.product_id} className="card">
                  <img src={subject.preview} alt="Preview" className="preview" />
                  <h2>{subject.name}</h2>
                  {loadingPaper === purchase.product_id ? (
                  <div style={{ marginTop: '12px' }}>
                 <span style={{ color: '#555' }}>Preparing your paper...</span>
                 <div className="spinner" />
             </div>
) : (
  <button onClick={() => handleView(purchase.product_id)}>View Paper</button>
)}
                </div>
              );
            })}
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="footer">&copy; {new Date().getFullYear()} SampleMint. All rights reserved.</footer>

      {/* Styles */}
      <style jsx>{`
        * {
          box-sizing: border-box;
        }
        body {
          margin: 0;
          font-family: Arial, sans-serif;
        }

        .navbar {
          display: flex;
          flex-direction: column;
          background: #007bff;
          color: white;
          padding: 16px;
        }

        .navbar-left {
          display: flex;
          justify-content: space-between;
          align-items: center;
        }

        .navbar-brand {
          font-size: 24px;
          font-weight: bold;
        }

        .brand-text {
          font-size: 28px;
          font-weight: 800;
        }

        .menu-btn {
          font-size: 24px;
          background: none;
          border: none;
          color: white;
          cursor: pointer;
        }

        .navbar-user {
          display: none;
          flex-direction: column;
          align-items: flex-start;
          padding-top: 10px;
        }

        .navbar-user.show {
          display: flex;
        }

        .user-email {
          margin-bottom: 8px;
        }

        .nav-link {
          background-color: #10b981;
          color: white;
          padding: 8px 16px;
          border-radius: 6px;
          border: none;
          cursor: pointer;
          font-weight: 600;
          margin-top: 8px;
        }

        .logout-btn {
          background-color: #ef4444;
          color: white;
          padding: 8px 16px;
          border-radius: 6px;
          border: none;
          cursor: pointer;
          font-weight: 600;
          margin-top: 8px;
        }

        .container {
          padding: 30px;
          min-height: 100vh;
          background: #f9f9f9;
        }

        .heading {
          text-align: center;
          font-size: 32px;
          margin-bottom: 40px;
        }

        .grid {
          display: flex;
          flex-wrap: wrap;
          gap: 20px;
          justify-content: center;
        }

        .card {
          border: 1px solid #ccc;
          border-radius: 10px;
          width: 250px;
          padding: 20px;
          text-align: center;
          background: white;
        }

        .preview {
          width: 100%;
          height: 150px;
          object-fit: cover;
          border-radius: 6px;
        }

        button {
          background: #2563eb;
          color: white;
          padding: 10px 20px;
          border: none;
          border-radius: 6px;
          cursor: pointer;
          margin-top: 12px;
        }

        .footer {
          text-align: center;
          padding: 20px;
          background: #007bff;
          color: white;
        }

        @media (min-width: 768px) {
          .navbar {
            flex-direction: row;
            justify-content: space-between;
            align-items: center;
          }

          .menu-btn {
            display: none;
          }

          .navbar-user {
            display: flex !important;
            flex-direction: row;
            align-items: center;
            gap: 16px;
            padding-top: 0;
          }

          .nav-link,
          .logout-btn {
            margin-top: 0;
          }
        }

        @media (max-width: 600px) {
          .grid {
            flex-direction: column;
            align-items: center;
          }
        }
          .spinner {
  margin: 10px auto;
  border: 4px solid #f3f3f3;
  border-top: 4px solid #2563eb;
  border-radius: 50%;
  width: 24px;
  height: 24px;
  animation: spin 1s linear infinite;
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

      `}</style>
    </div>
  );
}
